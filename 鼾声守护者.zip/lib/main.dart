// 新增这一行导入，这是关键！
import 'package:flutter/material.dart';
// 原有导入保持不变
import 'snore_watch.dart';

void main() {
  runApp(const SnoreWatchApp());
}